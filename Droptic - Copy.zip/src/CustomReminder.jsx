import React, { useState } from 'react';
import ImageSlider from './ImageSlider';
import ReminderToast from './ReminderToast';

const CUSTOM_IMAGES = ['/img4.png', '/img5.png', '/img6.png', '/img7.png'];
const CUSTOM_QUOTES = [
  'Stretch it out and reset your body.',
  'Time for a break—enjoy a moment',
  'Time to take pill, stay on track with health',
  'Take a short walk and recharge.'
];


const CustomReminder = ({ setError }) => {
  const [customTime, setCustomTime] = useState('');
  const [customMessage, setCustomMessage] = useState('');
  const [customUrl, setCustomUrl] = useState('');

  const handleInputChange = setter => e => {
    setter(e.target.value);
    setError('');
  };
  const labelStyle = {
  color: '#000000',
  fontWeight: '500',
  display: 'block',
  marginBottom: '6px'
};
  const isValidUrl = (string) => {
    try {
      new URL(string);
      return true;
    } catch (_) {
      return false;
    }
  };

  const setCustomReminder = () => {
    try {
      if (!customTime || !customMessage) {
        setError('Please fill in required fields');
        return;
      }

      const [hours, minutes] = customTime.split(':').map(Number);
      if (isNaN(hours) || isNaN(minutes) || hours < 0 || hours > 23 || minutes < 0 || minutes > 59) {
        setError('Invalid time format');
        return;
      }

      if (customUrl && !isValidUrl(customUrl)) {
        setError('Invalid URL format');
        return;
      }

      const now = new Date();
      const reminderTime = new Date();
      reminderTime.setHours(hours, minutes, 0);
      if (reminderTime < now) {
        reminderTime.setDate(reminderTime.getDate() + 1);
      }

     const delayInMinutes = (reminderTime - now) / 1000 / 60;
      if (delayInMinutes < 1) {
        setError('Reminder must be at least 1 minute ahead');
        return;
      }

      const alarmId = `customReminder-${Date.now()}`;
      chrome.alarms.create(alarmId, { delayInMinutes });


      chrome.storage.local.get(['customReminders'], (res) => {
        const customReminders = res.customReminders || [];
        customReminders.push({
          id: alarmId,
          time: customTime,
          message: customMessage,
          url: customUrl
        });

        chrome.storage.local.set({ customReminders }, () => {
          if (chrome.runtime.lastError) {
            setError('Failed to save reminder details');
            return;
          }

          chrome.notifications.create({
            type: 'basic',
            iconUrl: 'icon.png',
            title: 'Reminder Set',
            message: `Reminder set for ${customTime}`
          }, () => {
            if (chrome.runtime.lastError) {
              setError('Failed to show notification');
            } else {
              window.dispatchEvent(new Event('reminder-set'));
            }
          });
        });
      });
    } catch (err) {
      console.error(err);
      setError('Failed to set custom reminder');
    }
  };

  return (
    <div className="content">
    <ImageSlider images={CUSTOM_IMAGES} quotes={CUSTOM_QUOTES} />

     <h3 style={{ marginBottom: '20px', ...labelStyle }}>Set a Personalized Reminder</h3>


      <label htmlFor="time" style={labelStyle}>Reminder Time </label>

      <input
        type="time"
        value={customTime}
        onChange={handleInputChange(setCustomTime)}
        required
      />
       <label style={labelStyle}>
        Reminder Message
      </label>
      <input
        type="text"
        value={customMessage}
        onChange={handleInputChange(setCustomMessage)}
        placeholder="What would you like reminded about?"

        required
      />
        <label style={labelStyle}>
        Associated Link (Optional)
      </label>
      <input
        type="url"
        value={customUrl}
        onChange={handleInputChange(setCustomUrl)}
        placeholder="Add a link to open with this reminder"

      />
      <button onClick={setCustomReminder}>Set Reminder</button>
      <ReminderToast />
    </div>
  );
};

export default CustomReminder;
