import React, { useState, useEffect } from 'react';
import ImageSlider from './ImageSlider';
import ReminderToast from './ReminderToast'; // ✅ Added import

const EYE_IMAGES = ['/img1.png', '/img2.png', '/img3.png'];
const EYE_QUOTES = [
  'Rest your eyes—look away and relax.',
  '20‑20‑20! Look 20 feet away for 20 sec.', 
  'Stay hydrated — take a sip of water.'
];


const EyeReminder = ({ setError }) => {
  const [eyeInterval, setEyeInterval] = useState(20);
  const [lastSetInterval, setLastSetInterval] = useState(20);

  
  useEffect(() => {
    try {
      chrome.storage.local.get(['eyeInterval'], (result) => {
        if (chrome.runtime.lastError) return setError('Failed to load settings');
         if (result?.eyeInterval) {
          const interval = Number(result.eyeInterval);
          setEyeInterval(interval);

          // ✅ Also update displayed message on load
          setLastSetInterval(interval);     
        } 
        
      });
    } catch (err) {
      setError('Failed to access storage');
    }
  }, [setError]);

  const setEyeReminder = () => {
    try {
      const interval = Number(eyeInterval);
      // Enforce minimum of 5 minutes
      if (isNaN(interval) || interval < 5|| interval > 1330) {
        setError('Minimum interval is 5 minutes');
        return;
      }
      chrome.storage.local.set({ eyeInterval: interval }, () => {
        if (chrome.runtime.lastError) return setError('Failed to save eye interval');
        chrome.alarms.create('eyeReminder', {
          periodInMinutes: interval+1
        }, () => {
          if (chrome.runtime.lastError) return setError('Failed to set eye reminder');
          chrome.notifications.create({
            type: 'basic',
            iconUrl: 'icon.png',
            title: 'Eye Reminder Set',
            message: `Reminder set for every ${interval} minutes`
          }, () => {
            if (chrome.runtime.lastError) setError('Failed to show notification');
            window.dispatchEvent(new Event('reminder-set')); // ✅ Trigger toast

            setLastSetInterval(interval);
          });
        });
      });
    } catch (err) {
      setError('Failed to set reminder');
    }
  };

  return (
    <>
      <div className="content">
       <ImageSlider images={EYE_IMAGES} quotes={EYE_QUOTES} />

        <h3>Eye Break Interval</h3>
        <input
          type="number"
          value={eyeInterval}
          onChange={e => setEyeInterval(Math.max(5, Number(e.target.value) || 5))}
          placeholder="Interval in minutes"
          min="5"
        />
        <button onClick={setEyeReminder}>Set Reminder</button> 
        <p style={{ marginTop: '10px', fontWeight: 'bold' }}>
                You set interval to: {lastSetInterval} minutes
        </p>
      </div>
      <ReminderToast /> {/* ✅ Toast message component */}
    </>
  );
};

export default EyeReminder;
