import React from 'react';


const Header = () => {
    return (
        <div className="header">
            <h1 className="brand-name">Droptic</h1>
            <div className="social-icons">
                <a href="https://github.com/sri-varshith-reddy/Droptic" target="_blank" rel="noopener noreferrer">
                    <i className="fab fa-github"></i>
                </a>
                <a href="https://www.linkedin.com/in/srivarshithreddy" target="_blank" rel="noopener noreferrer">
                    <i className="fab fa-linkedin"></i>
                </a>
            </div>
        </div>
    );
};

export default Header;
