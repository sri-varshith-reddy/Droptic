// ImageSlider.js

import React, { useState, useEffect } from 'react';

const DEFAULT_IMAGES = [
  '/img1.png',
  '/img2.png',
  '/img3.png',
  '/img4.png',
  '/img5.png',
  '/img6.png',
  '/img7.png',
];

const ImageSlider = ({
  images = DEFAULT_IMAGES,
  quotes = [],          // ← added quotes prop
  interval = 3000       // ← unchanged default
}) => {
  const [index, setIndex] = useState(0);

  useEffect(() => {
    const id = setInterval(
      () => setIndex(i => (i + 1) % images.length),
      interval
    );
    return () => clearInterval(id);
  }, [images, interval]);

  return (
    <div style={{ textAlign: 'center' }}>
      <div
        style={{
          width: '100%',
          height: '180px',
          overflow: 'hidden',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          backgroundColor: 'transparent',
        }}
      >
        <img
          src={images[index]}
          alt={`slide-${index}`}
          style={{
            maxWidth: '100%',
            maxHeight: '100%',
            objectFit: 'contain',
             borderRadius: '12px',     // ← add this
           boxShadow: '0 2px 8px rgba(0,0,0,0.15)' 
          }}
        />
      </div>
      {quotes.length > 0 && (
        <p style={{ marginTop: '8px', marginBottom: '8px', fontStyle: 'italic' }}>
          {quotes[index]}
        </p>
      )}
    </div>
  );
};

export default ImageSlider;
