import React, { useEffect, useState } from 'react';

const ReminderToast = () => {
  const [show, setShow] = useState(false);

  useEffect(() => {
    const onSet = () => {
      setShow(true);
      setTimeout(() => setShow(false), 2000);
    };
    window.addEventListener('reminder-set', onSet);
    return () => window.removeEventListener('reminder-set', onSet);
  }, []);

  const style = {
    position: 'fixed',
    bottom: '40px',
    left: '50%',
    transform: 'translateX(-50%)',
    background: '#222',
    color: '#fff',
    padding: '12px 24px',
    borderRadius: '24px',
    boxShadow: '0 4px 12px rgba(0,0,0,0.3)',
    opacity: show ? 1 : 0,
    transition: 'opacity 0.3s ease-in-out',
    pointerEvents: 'none',
    fontSize: '14px',
  };

  return <div style={style}>✅ Reminder set!</div>;
};

export default ReminderToast;
