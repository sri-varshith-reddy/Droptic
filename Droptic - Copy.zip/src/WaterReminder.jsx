import React, { useState, useEffect } from 'react';
// ADDED: import confetti for 100% celebration
import confetti from 'canvas-confetti';

// Milestone quotes with 💧 symbol added
const quotes = {
  0: "<span style='color:#28A9A4;'>💧</span> Let’s get started!",
  25: "<span style='color:#28A9A4;'>💧</span> Keep going, you’re great!!",
  50: "<span style='color:#28A9A4;'>💧</span> Halfway, stay strong!",
  75: "<span style='color:#28A9A4;'>💧</span> Almost at the finish line!",
  100: "<span style='color:#28A9A4;'>💧</span> Goal achieved! Celebrate!"
};

const styles={
        marginTop: '8px',
        color: '#000000',
        fontSize: '14px',
        fontWeight: 500,
        
      }
const inputstyles={
    marginTop: '8px',
        color: '#28a9a4',
        fontSize: '14px',
        fontWeight: 500,
        width: '80px', 
        marginRight: '8px'
}
const getBracket = pct => {
  if (pct>=99) return 100;
  if (pct >= 75) return 75;
  if (pct >= 50) return 50;
  if (pct >= 25) return 25;
  return 0;
};

const WaterReminder = ({ setError }) => {
  const [waterTarget, setWaterTarget] = useState(2000);
  const [waterIntake, setWaterIntake] = useState(0);

  // NEW: allow setting custom log amount
  const [logAmount, setLogAmount] = useState(250);

  const [message, setMessage] = useState('Keep it Up! 💧');
  const [animClass, setAnimClass] = useState('');

  useEffect(() => {
    try {
      chrome.storage.local.get(['waterIntake', 'lastResetDate', 'waterTarget'], (result) => {
        if (chrome.runtime.lastError) return setError('Failed to load water intake data');
        const today = new Date().toDateString();
        if (!result.lastResetDate || result.lastResetDate !== today) {
          setWaterIntake(0);
          chrome.storage.local.set({ waterIntake: 0, lastResetDate: today });
        } else if (result?.waterIntake) {
          setWaterIntake(Number(result.waterIntake));
        }
        if (result?.waterTarget) setWaterTarget(Number(result.waterTarget));
      });
    } catch (err) {
      setError('Failed to access storage');
    }
  }, [setError]);

  const updateFeedback = pct => {
    const tier = getBracket(pct);
    if (quotes[tier] !== undefined) {
      setMessage(quotes[tier]);
      setAnimClass('pulse');
      if (pct === 100) {
        confetti({ particleCount: 100, spread: 60, origin: { y: 0.6 } });
      }
      setTimeout(() => setAnimClass(''), 1000);
    }
  };

  const logWater = () => {
    try {
      const newIntake = Number(waterIntake) + Number(logAmount);
      if (isNaN(newIntake)) {
        setError('Invalid water intake value');
        return;
      }
      setWaterIntake(newIntake);
      chrome.storage.local.set({ waterIntake: newIntake, lastResetDate: new Date().toDateString() });
      const pct = Math.min(100, Math.round((newIntake / Math.max(2000, waterTarget)) * 100));
      updateFeedback(pct);
    } catch (err) {
      setError('Failed to log water intake');
    }
  };

  const safeWaterTarget = Math.max(2000, waterTarget);
  const percent = Math.min(100, Math.round((waterIntake / safeWaterTarget) * 100));

  return (
    <div className="content">
      <div className={`water-card ${animClass}`}>
        <div className="water-progress">{percent}%</div>
        <div className="water-label" dangerouslySetInnerHTML={{ __html: message }}></div>
        <div className="water-progress-bar">
          <div className="water-progress-bar-inner" style={{ width: percent + '%' }} />
        </div>
      </div>

      {/* Daily target / capacity */}
     <label style={styles}>

        Daily Target (ml):
        <input
          type="number"
          value={waterTarget}
          onChange={e => {
            const value = Math.max(0, Number(e.target.value) || 0);
            setWaterTarget(value);
            chrome.storage.local.set({ waterTarget: value });
          }}
          placeholder="Daily target (ml)"
          min="0"
          style={inputstyles}
        />
      </label>

      {/* Log input only (intake removed) */}
      <div className="water-log" style={{ marginTop: '8px' }}>
        <label style={styles}>Log (ml):</label>
        <input
          type="number"
          value={logAmount}
          onChange={e => setLogAmount(Math.max(0, Number(e.target.value) || 0))}
          style={inputstyles}
          min="0"
          
        />
        <button onClick={logWater}>+ {logAmount}ml</button>
      </div>

      {/* Bottom line – untouched */}
      <div style={styles}>
      Progress: <span style={inputstyles}>{waterIntake}/{safeWaterTarget}ml</span>
    </div>

    </div>
  );
};

export default WaterReminder;
